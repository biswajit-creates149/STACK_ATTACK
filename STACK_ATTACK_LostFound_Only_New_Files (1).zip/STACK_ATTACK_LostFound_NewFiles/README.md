# STACK_ATTACK - CampusConnect

## Run locally

1. Install Node.js (LTS).
2. Open a terminal in this folder.
3. Run:

```bash
npm install
npm start
```

4. Open http://localhost:3000/lost-found.html

## Lost & Found API

- `GET /api/lost-found` - returns all Lost & Found items.
- `POST /api/lost-found` - creates a new item.

Data is stored in `data/lost-items.json` for this prototype. For production, replace this file storage with a shared database such as MongoDB/PostgreSQL.
