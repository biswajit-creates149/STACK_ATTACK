const express = require('express');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'lost-items.json');

app.use(express.json());
app.use(express.static(__dirname));

function readItems() {
  if (!fs.existsSync(DATA_FILE)) return [];
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
  } catch (error) {
    console.error('Could not read lost-items.json:', error);
    return [];
  }
}

function writeItems(items) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(DATA_FILE, JSON.stringify(items, null, 2));
}

// GET all Lost & Found items
app.get('/api/lost-found', (req, res) => {
  const items = readItems();
  res.json(items);
});

// POST a new Lost & Found item
app.post('/api/lost-found', (req, res) => {
  const { type, name, location, description, contact, email } = req.body;

  if (!type || !name || !location || !description || !contact) {
    return res.status(400).json({
      message: 'type, name, location, description and contact are required.'
    });
  }

  const item = {
    id: Date.now().toString(),
    type,
    name: String(name).trim(),
    location: String(location).trim(),
    description: String(description).trim(),
    contact: String(contact).trim(),
    email: email || '',
    date: new Date().toLocaleDateString('en-IN')
  };

  const items = readItems();
  items.unshift(item);
  writeItems(items);

  res.status(201).json(item);
});

app.listen(PORT, () => {
  console.log(`STACK_ATTACK running at http://localhost:${PORT}`);
});
